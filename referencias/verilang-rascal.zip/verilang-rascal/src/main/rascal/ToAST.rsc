module ToAST

import ParseTree;
import AST;
import Syntax;
import String;

Program toProgram(Tree t) {
  visit(t) {
    case m: appl(prod(sort("Module"), _, _), _):
      return prog(toModule(m));
  }

  throw "No se encontró Module dentro del Program";
}

VModule toModule(Tree t) {
  str txt = unparse(t);
  list[str] lines = split("\n", txt);

  str firstLine = trim(lines[0]);
  str moduleName = trim(replaceAll(firstLine, "defmodule", ""));

  return vModule(
    moduleName,
    toUsingList(t),
    toComponents(t)
  );
}


bool isUsing(Tree t) {
  return contains(unparse(t), "using");
}

list[str] toUsingList(Tree t) {
  list[str] result = [];

  visit(t) {
    case u: appl(_, _):
      if (isUsing(u)) {
        result += [unparse(u)];
      }
  }

  return result;
}

list[Component] toComponents(Tree t) {
  list[Component] result = [];

  visit(t) {
    case appl(prod(label("opDef", _), _, _), kids):
      result += [operComp(operDef(trim(unparse(kids[2])), toType(kids[6])))];
    case appl(prod(label("spaceSimple", _), _, _), kids):
      result += [spaceComp(simpleSpace(trim(unparse(kids[2]))))];
    case appl(prod(label("spaceOrdered", _), _, _), kids):
      result += [spaceComp(orderedSpace(trim(unparse(kids[2])), trim(unparse(kids[6]))))];
    case appl(prod(label("ruleDef", _), _, _), kids):
      result += [ruleComp(toRule(appl(prod(label("ruleDef", sort("RuleComponent")), [], {}), kids)))];
    case appl(prod(label("varComp", _), _, _), kids):
      result += [variableComp(varBlock(toVarDecls(kids[2])))];
    case appl(prod(label("exprNoAttr", _), _, _), kids):
      result += [exprComp(exprDecl(toLogicExpr(kids[2]), []))];
    case appl(prod(label("equationDef", _), _, _), kids):
      result += [equationComp(equationDecl(toLogicExpr(kids[2]), toLogicExpr(kids[4])))];
  }

  return result;
}

Component toComponent(Tree t) {
  if (isSpace(t)) {
    return spaceComp(toSpace(t));
  }

  if (isRule(t)) {
    return ruleComp(toRule(t));
  }

  if (isOperator(t)) {
    return operComp(toOper(t));
  }

  if (isVariable(t)) {
    return variableComp(toVarBlock(t));
  }

  if (contains(unparse(t), "defexpression")) {
    return exprComp(toExpr(t));
  }

  if (contains(unparse(t), "defequation")) {
    return equationComp(toEquation(t));
  }

  return spaceComp(simpleSpace("temp"));
}

bool isSpace(Tree t) {
  return contains(unparse(t), "defspace");
}

bool isRule(Tree t) {
  return contains(unparse(t), "defrule");
}

SpaceDecl toSpace(Tree t) {
  switch (t) {
    case appl(_, [_, name, _]):
      return simpleSpace(unparse(name));

    case appl(_, [_, name1, _, name2, _]):
      return orderedSpace(unparse(name1), unparse(name2));
  }

  throw "No se pudo convertir SpaceComponent";
}

Term toTerm(Tree t) {
  switch (t) {

    case appl(prod(sort("Argument"), _, _), kids):
      return toTerm(kids[0]);

    case appl(prod(label("termApp", _), _, _), kids):
      return toTerm(kids[0]);

    case appl(prod(label("termName", _), _, _), kids):
      return nameTerm(trim(unparse(kids[0])));

    case appl(prod(label("termInt", _), _, _), kids):
      return intTerm(toInt(trim(unparse(kids[0]))));

    case appl(prod(label("termFloat", _), _, _), kids):
      return realTerm(toReal(trim(unparse(kids[0]))));
    
    case appl(prod(label("termString", _), _, _), kids):
      return stringTerm(trim(unparse(kids[0])));

    case appl(prod(label("termChar", _), _, _), kids):
      return charTerm(trim(unparse(kids[0])));

    case appl(prod(sort("Application"), _, _), kids):
      return appTerm(trim(unparse(kids[2])), toArgs(t));
  }

  str txt = trim(unparse(t));

  if (/^[a-zA-Z][a-zA-Z0-9\-]*$/ := txt) {
    return nameTerm(txt);
  }

  if (/^[0-9]+$/ := txt) {
    return intTerm(toInt(txt));
  }

  if (/^[0-9]+\.[0-9]+$/ := txt) {
    return realTerm(toReal(txt));
  }

  if (/^".*"$/ := txt) {
  return stringTerm(txt);
  }

  if (/^'.'$/ := txt) {
    return charTerm(txt);
  }

  throw "No se pudo convertir Term: <txt>";
}


list[Term] toArgs(Tree t) {
  list[Term] result = [];

  visit(t) {
    case a: appl(prod(sort("Argument"), _, _), _):
      result += [toTerm(a)];
  }

  return result;
}

RuleDecl toRule(Tree t) {
  switch (t) {
    case appl(prod(label("ruleDef", _), _, _), kids):
      return ruleDecl(toTerm(kids[2]), toTerm(kids[6]));
  }

  throw "No se pudo convertir RuleComponent";
}

RelOp toRelOp(Tree t) {
  str txt = unparse(t);

  if (txt == "in") {
    return inOp();
  }

  if (txt == "\u003C\u003D") {
    return lessEqOp();
  }

  if (txt == "\u003E\u003D") {
    return greaterEqOp();
  }

  if (txt == "\u003C") {
    return lessOp();
  }

  if (txt == "\u003E") {
    return greaterOp();
  }

  if (txt == "\u003C\u003E") {
    return notEqualOp();
  }

  return equalOp();
}

LogicExpr toRelation(Tree t) {
  switch (t) {
    case appl(prod(label("relEqual", _), _, _), kids):
      return relationExpr(toTerm(kids[0]), equalOp(), toTerm(kids[4]));
    case appl(prod(label("relLessEq", _), _, _), kids):
      return relationExpr(toTerm(kids[0]), lessEqOp(), toTerm(kids[4]));
    case appl(prod(label("relGreaterEq", _), _, _), kids):
      return relationExpr(toTerm(kids[0]), greaterEqOp(), toTerm(kids[4]));
    case appl(prod(label("relNotEqual", _), _, _), kids):
      return relationExpr(toTerm(kids[0]), notEqualOp(), toTerm(kids[4]));
    case appl(prod(label("relLess", _), _, _), kids):
      return relationExpr(toTerm(kids[0]), lessOp(), toTerm(kids[4]));
    case appl(prod(label("relGreater", _), _, _), kids):
      return relationExpr(toTerm(kids[0]), greaterOp(), toTerm(kids[4]));
    case appl(prod(label("relIn", _), _, _), kids):
      return relationExpr(toTerm(kids[0]), inOp(), toTerm(kids[4]));
  }
  throw "No se pudo convertir Relation: <unparse(t)>";
}

LogicExpr toLogicExpr(Tree t) {
  if (appl(prod(label("forallExpr", _), _, _), _) := t) return toForall(t);
  if (appl(prod(label("existsExpr", _), _, _), _) := t) return toExists(t);
  if (appl(prod(label("negExpr", _), _, _), _) := t) return toNeg(t);
  if (appl(prod(label("andChain", _), _, _), _) := t) return toAnd(t);
  if (appl(prod(label("orChain", _), _, _), _) := t) return toOr(t);
  if (appl(prod(label(/^rel/, _), _, _), _) := t) return toRelation(t);

  LogicExpr found = termExpr(nameTerm("?"));
  visit(t) {
    case r: appl(prod(label(/^rel/, _), _, _), _):
      found = toRelation(r);
    case andNode: appl(prod(label("andChain", _), _, _), _):
      found = toAnd(andNode);
    case orNode: appl(prod(label("orChain", _), _, _), _):
      found = toOr(orNode);
  }
  return found;
}
ExprDecl toExpr(Tree t) {
  switch (t) {
    case appl(_, [_, expr, _, _]):
      return exprDecl(toLogicExpr(expr), []);

    case appl(_, [_, expr, _, _, _]):
      return exprDecl(toLogicExpr(expr), []);
  }

  throw "No se pudo convertir ExpressionComponent";
}

EquationDecl toEquation(Tree t) {
  switch (t) {
    case appl(_, [_, left, _, right, _]):
      return equationDecl(toLogicExpr(left), toLogicExpr(right));
  }

  throw "No se pudo convertir EquationComponent";
}

bool isOperator(Tree t) {
  return contains(unparse(t), "defoperator");
}

bool isVariable(Tree t) {
  return contains(unparse(t), "defvar");
}

OperDef toOper(Tree t) {
  str raw = unparse(t);
  str sinDef = trim(replaceAll(raw, "defoperator", ""));
  str sinEnd = trim(replaceAll(sinDef, "end", ""));
  list[str] partes = split(":", sinEnd);
  if (size(partes) >= 2) {
    str nombre = trim(partes[0]);
    str tipo = trim(partes[1]);
    return operDef(nombre, simpleType(tipo));
  }

  throw "No se pudo convertir OperatorComponent";
}

VarBlock toVarBlock(Tree t) {
  return varBlock(toVarDecls(t));
}

VType toType(Tree t) {
  switch (t) {
    case appl(prod(label("arrowType", _), _, _), kids):
      return arrowType(simpleType(trim(unparse(kids[0]))), toType(kids[4]));
    case appl(prod(label("simpleType", _), _, _), kids):
      return simpleType(trim(unparse(kids[0])));
  }
  throw "No se pudo convertir Type";
}

list[VarDecl] toVarDecls(Tree t) {
  list[VarDecl] result = [];

  visit(t) {
    case d: appl(prod(label("varDecl", _), _, _), _):
      result += [toVarDecl(d)];
  }

  return result;
}

VarDecl toVarDecl(Tree t) {
  switch (t) {
    case appl(prod(label("varDecl", _), _, _), kids):
      return varDecl(trim(unparse(kids[0])), toType(kids[4]));
  }

  throw "No se pudo convertir VarDecl";
}

bool isNeg(Tree t) {
  return appl(prod(label("negExpr", _), _, _), _) := t;
}

bool isAnd(Tree t) {
  return appl(prod(label("andChain", _), _, _), _) := t;
}

bool isOr(Tree t) {
  return appl(prod(label("orChain", _), _, _), _) := t;
}

bool isForall(Tree t) {
  return appl(prod(label("forallExpr", _), _, _), _) := t;
}

bool isExists(Tree t) {
  return appl(prod(label("existsExpr", _), _, _), _) := t;
}

LogicExpr toNeg(Tree t) {
  switch (t) {
    case appl(prod(label("negExpr", _), _, _), kids):
      return negExpr(toLogicExpr(kids[2]));
  }
  throw "No se pudo convertir neg";
}

LogicExpr toAnd(Tree t) {
  switch (t) {
    case appl(prod(label("andChain", _), _, _), kids):
      return andExpr([toLogicExpr(kids[0]), toLogicExpr(kids[4])]);
  }
  throw "No se pudo convertir and";
}


LogicExpr toOr(Tree t) {
  switch (t) {
    case appl(prod(label("orChain", _), _, _), kids):
      return orExpr([toLogicExpr(kids[0]), toLogicExpr(kids[4])]);
  }
  throw "No se pudo convertir or";
}

LogicExpr toForall(Tree t) {
  switch (t) {
    case appl(_, [_, var, _, body]):
      return forallExpr(unparse(var), noSpace(), toLogicExpr(body));

    case appl(_, [_, var, _, space, _, body]):
      return forallExpr(unparse(var), inSpace(unparse(space)), toLogicExpr(body));
  }

  throw "No se pudo convertir forall";
}

LogicExpr toExists(Tree t) {
  switch (t) {
    case appl(_, [_, var, _, body]):
      return existsExpr(unparse(var), noSpace(), toLogicExpr(body));

    case appl(_, [_, var, _, space, _, body]):
      return existsExpr(unparse(var), inSpace(unparse(space)), toLogicExpr(body));
  }

  throw "No se pudo convertir exists";
}